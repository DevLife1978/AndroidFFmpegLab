#include "log.h"

int muxing(const char* output);