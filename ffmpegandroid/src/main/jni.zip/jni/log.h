#include <android/log.h>

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "FFMPEG", __VA_ARGS__)
#define LOG(...) LOGI(__VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "FFMPEG", __VA_ARGS__)
#define CHECK(count) LOG("Check %s:%d", __PRETTY_FUNCTION__, __LINE__)