
#include <jni.h>
#include <string.h>

#include "log.h"

#include <app_jni_ffmpegandroid_ffmpeglib.h>

#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libavutil/avutil.h>

#include "dump.h"
#include "decoding_encoding.h"
#include <android/bitmap.h>
#include "transcoding.h"
#include "transcode_aac.h"
#include "demuxing_decoding.h"
#include <errno.h>
#include <libavutil/avassert.h>
#include "muxing.h"
#include "remuxing.h"

void audio_decode(const char *output, const char *input, AVCodecContext *ctx);
void video_decode(const char *outfilename, const char *filename);
static int decode_write_frame(const char *outfilename, AVCodecContext *avctx,
                              AVFrame *frame, int *frame_count, AVPacket *pkt, int last);

static void pgm_save(unsigned char *buf, int wrap, int xsize, int ysize,
                     char *filename);

void av_dump(const char* media_path) {
       AVFormatContext *fmt_ctx = NULL;
       AVDictionaryEntry *tag = NULL;
       int ret;

       if ((ret = avformat_open_input(&fmt_ctx, media_path, NULL, NULL)))
           return;
       if( 0 > avformat_find_stream_info(fmt_ctx, NULL)) {
        __android_log_print(ANDROID_LOG_INFO, "FFMPEG", "Error while calling avformat_find_stream_info");
       }

       for( int i = 0 ; i < fmt_ctx->nb_streams ; i++) {
        AVStream *stream = fmt_ctx->streams[i];
        if(NULL != stream) {
            enum AVCodecID codecId = stream->codec->codec_id;
            AVCodec *codec = avcodec_find_decoder(codecId);
            __android_log_print(ANDROID_LOG_INFO, "FFMPEG", "Codec %s %dx%d", codec->name, stream->codec->width, stream->codec->height);
        }
       }

       while ((tag = av_dict_get(fmt_ctx->metadata, "", tag, AV_DICT_IGNORE_SUFFIX)))
           __android_log_print(ANDROID_LOG_INFO, "FFMPEG", "%s=%s\n", tag->key, tag->value);

       avformat_close_input(&fmt_ctx);
}

void av_dump_format2(AVFormatContext *fmt_ctx) {
       AVDictionaryEntry *tag = NULL;
       int ret;

       for( int i = 0 ; i < fmt_ctx->nb_streams ; i++) {
        AVStream *stream = fmt_ctx->streams[i];
        if(NULL != stream) {
            enum AVCodecID codecId = stream->codec->codec_id;
            AVCodec *codec = avcodec_find_decoder(codecId);
            __android_log_print(ANDROID_LOG_INFO, "FFMPEG", "Codec %s %dx%d", codec->name, stream->codec->width, stream->codec->height);
        }
       }

       while ((tag = av_dict_get(fmt_ctx->metadata, "", tag, AV_DICT_IGNORE_SUFFIX)))
           __android_log_print(ANDROID_LOG_INFO, "FFMPEG", "%s=%s\n", tag->key, tag->value);
}

static void av_dump_codec(AVCodecContext *ctx) {
    LOGI("<----- DUMP CODEC ------>");
    LOGI("Media type %d", ctx->codec_type);
    LOGI("Codec id %d", ctx->codec_id);
    LOGI("Codec tag %s", (char *)&(ctx->codec_tag));
    LOGI("Codec stream tag %s", (char *)&(ctx->stream_codec_tag));
    LOGI("bitrate %d", ctx->bit_rate);
    LOGI("bitrate tolerance %d", ctx->bit_rate_tolerance);
    LOGI("global quality %d", ctx->global_quality);
    LOGI("compression level %d", ctx->compression_level);
    LOGI("pixel format %d", ctx->pix_fmt);
}

JNIEXPORT void JNICALL Java_app_jni_ffmpegandroid_ffmpeglib_dump(JNIEnv *env, jobject obj, jstring string)
{
    const char * media_path = (*env)->GetStringUTFChars(env, string, 0);
    return;
}

JNIEXPORT void JNICALL Java_app_jni_ffmpegandroid_ffmpeglib_initialize
  (JNIEnv *env, jobject obj) {
    avcodec_register_all();
    av_register_all();
  }

JNIEXPORT jlong JNICALL Java_app_jni_ffmpegandroid_ffmpeglib_media_1length(JNIEnv *env, jobject obj, jstring string)
{
    const char * media_path = (*env)->GetStringUTFChars(env, string, 0);
//    __android_log_print(ANDROID_LOG_INFO, "FFMPEG", "Media path -> %s", media_path);
    AVFormatContext *media_format = NULL;
    if(avformat_open_input(&media_format, media_path, NULL, NULL)) {
        __android_log_print(ANDROID_LOG_INFO, "FFMPEG", "input file error");
        return 0;
    }
    int64_t duration = media_format->duration;
    avformat_close_input(&media_format);
    media_format = NULL;
    return duration;
}

char get_media_type_char(enum AVMediaType type)
{
    switch (type) {
        case AVMEDIA_TYPE_VIDEO:    return 'V';
        case AVMEDIA_TYPE_AUDIO:    return 'A';
        case AVMEDIA_TYPE_DATA:     return 'D';
        case AVMEDIA_TYPE_SUBTITLE: return 'S';
        case AVMEDIA_TYPE_ATTACHMENT:return 'T';
        default:                    return '?';
    }
}

const AVCodec *next_codec_for_id(enum AVCodecID id, const AVCodec *prev,
                                        int encoder)
{
    while ((prev = av_codec_next(prev))) {
        if (prev->id == id &&
            (encoder ? av_codec_is_encoder(prev) : av_codec_is_decoder(prev)))
            return prev;
    }
    return NULL;
}

void print_codecs_for_id(enum AVCodecID id, int encoder)
{
    const AVCodec *codec = NULL;

    char *desc;
    sprintf(desc," (%s: ", encoder ? "encoders" : "decoders");
    LOGI("CODEC %s", desc);

    while ((codec = next_codec_for_id(id, codec, encoder)))
        LOGI("%s ", codec->name);

    LOGI(")");
}

int compare_codec_desc(const void *a, const void *b)
{
    const AVCodecDescriptor * const *da = a;
    const AVCodecDescriptor * const *db = b;

    return (*da)->type != (*db)->type ? (*da)->type - (*db)->type :
           strcmp((*da)->name, (*db)->name);
}

unsigned get_codecs_sorted(const AVCodecDescriptor ***rcodecs)
{
    const AVCodecDescriptor *desc = NULL;
    const AVCodecDescriptor **codecs;
    unsigned nb_codecs = 0, i = 0;

    while ((desc = avcodec_descriptor_next(desc)))
        nb_codecs++;
    if (!(codecs = av_calloc(nb_codecs, sizeof(*codecs)))) {
        av_log(NULL, AV_LOG_ERROR, "Out of memory\n");
        exit(1);
    }
    desc = NULL;
    while ((desc = avcodec_descriptor_next(desc)))
        codecs[i++] = desc;
    av_assert0(i == nb_codecs);
    qsort(codecs, nb_codecs, sizeof(*codecs), compare_codec_desc);
    *rcodecs = codecs;
    return nb_codecs;
}

int show_codecs(void *optctx, const char *opt, const char *arg)
{
    const AVCodecDescriptor **codecs;
    unsigned i, nb_codecs = get_codecs_sorted(&codecs);

    LOGI("Codecs:\n"
           " D..... = Decoding supported\n"
           " .E.... = Encoding supported\n"
           " ..V... = Video codec\n"
           " ..A... = Audio codec\n"
           " ..S... = Subtitle codec\n"
           " ...I.. = Intra frame-only codec\n"
           " ....L. = Lossy compression\n"
           " .....S = Lossless compression\n"
           " -------\n");
    for (i = 0; i < nb_codecs; i++) {
        const AVCodecDescriptor *desc = codecs[i];
        const AVCodec *codec = NULL;

        if (strstr(desc->name, "_deprecated"))
            continue;

        char des[1000];
        sprintf(des, " %s%s%c%s%s%s %-20s %s",
        (avcodec_find_decoder(desc->id) ? "D" : "."),
        (avcodec_find_encoder(desc->id) ? "E" : "."),
        (get_media_type_char(desc->type)),
        ((desc->props & AV_CODEC_PROP_INTRA_ONLY) ? "I" : "."),
        ((desc->props & AV_CODEC_PROP_LOSSY)      ? "L" : "."),
        ((desc->props & AV_CODEC_PROP_LOSSLESS)   ? "S" : "."),
        desc->name, (desc->long_name ? desc->long_name : ""));

        LOGI("%s",des);

        /* print decoders/encoders when there's more than one or their
         * names are different from codec name */
//        while ((codec = next_codec_for_id(desc->id, codec, 0))) {
//            if (strcmp(codec->name, desc->name)) {
//                print_codecs_for_id(desc->id, 0);
//                break;
//            }
//        }
//        codec = NULL;
//        while ((codec = next_codec_for_id(desc->id, codec, 1))) {
//            if (strcmp(codec->name, desc->name)) {
//                print_codecs_for_id(desc->id, 1);
//                break;
//            }
//        }

        printf("\n");
    }
    av_free(codecs);
    return 0;
}

static int init_filters(void)
{
    const char *filter_spec;
    unsigned int i;
    int ret;
    filter_ctx = av_malloc_array(ifmt_ctx->nb_streams, sizeof(*filter_ctx));
    if (!filter_ctx)
        return AVERROR(ENOMEM);

    for (i = 0; i < ifmt_ctx->nb_streams; i++) {
        filter_ctx[i].buffersrc_ctx  = NULL;
        filter_ctx[i].buffersink_ctx = NULL;
        filter_ctx[i].filter_graph   = NULL;
        if (!(ifmt_ctx->streams[i]->codec->codec_type == AVMEDIA_TYPE_AUDIO
                || ifmt_ctx->streams[i]->codec->codec_type == AVMEDIA_TYPE_VIDEO))
            continue;


        if (ifmt_ctx->streams[i]->codec->codec_type == AVMEDIA_TYPE_VIDEO)
            filter_spec = "null"; /* passthrough (dummy) filter for video */
        else
            filter_spec = "anull"; /* passthrough (dummy) filter for audio */
        ret = init_filter(&filter_ctx[i], ifmt_ctx->streams[i]->codec,
                ofmt_ctx->streams[i]->codec, filter_spec);
        if (ret)
            return ret;
    }
    return 0;
}

JNIEXPORT void JNICALL Java_app_jni_ffmpegandroid_ffmpeglib_ffmpeg_1test
  (JNIEnv *env, jobject obj, jstring input, jstring output) {
    const char *input_path = (*env)->GetStringUTFChars(env, input, 0);
    const char *output_path = (*env)->GetStringUTFChars(env, output, 0);

    AVFormatContext *input_format_context = NULL;
    int ret = avformat_open_input(&input_format_context, input_path, NULL, NULL);
    LOGI("Streams count -> %d", input_format_context->nb_streams);

    if(avformat_find_stream_info(input_format_context, NULL) < 0) {
        LOGE("Couldn't find stream info");
        return;
    }

    LOGI("<Initialize for decode>");
    av_dump_format2(input_format_context);

    AVCodecContext *dec_video_codec_ctx = NULL;
    AVCodecContext *dec_audio_codec_ctx = NULL;

    for(int i= 0 ; i<input_format_context->nb_streams ; i++) {
        AVStream *stream = input_format_context->streams[i];
        AVCodecContext *codec_ctx = stream->codec;
        AVCodec *decoder = avcodec_find_decoder(codec_ctx->codec_id);
        char *type = "";
        switch(codec_ctx->codec_type) {
            case AVMEDIA_TYPE_VIDEO:
            {
                type = "Video";
                dec_video_codec_ctx = codec_ctx;
            }
            break;
            case AVMEDIA_TYPE_AUDIO:
            {
                type = "Audio";
                dec_audio_codec_ctx = codec_ctx;
            }
            break;
        }
        LOGI("Stream %d type %s", i, type);
        if(decoder){
            LOGI("%s decoder -> %s", type, decoder->name);
            if(0 > avcodec_open2(codec_ctx, decoder, NULL)) {
                LOGE("Couldn't open %s decoder %s", type, decoder->name);
                return;
            }
            av_dump_codec(codec_ctx);
        }
        else {
            LOGE("Couldn't load %s decoder", type);
            return;
        }
    }
    LOGI("<Initialize for encode>");
    AVFormatContext *output_format_context = NULL;
    AVCodecContext *enc_video_codec_ctx = NULL;
    AVCodecContext *enc_audio_codec_ctx = NULL;
    LOGI("output path -> %s", output_path);
    avformat_alloc_output_context2(&output_format_context, NULL, NULL, output_path);
    if(NULL == output_format_context){
        LOGE("Couldn't allocate output format context");
        return;
    }

    for(int i = 0 ; i < input_format_context->nb_streams ; i++) {
        switch(input_format_context->streams[i]->codec->codec_type){
            case AVMEDIA_TYPE_VIDEO:
            {
                    AVStream *input_stream = input_format_context->streams[i];
                    AVCodecContext *input_codec_ctx = input_stream->codec;

                    AVStream *out_stream = avformat_new_stream(output_format_context, NULL);
                    if(NULL == out_stream) {
                        LOGE("Couldn't create new output stream");
                        return;
                    }

                AVCodec *encoder = avcodec_find_encoder(AV_CODEC_ID_MPEG1VIDEO);
                enc_video_codec_ctx = avcodec_alloc_context3(encoder);
                out_stream->codec = enc_video_codec_ctx;
                output_format_context->streams[0] = out_stream;
                if(NULL == encoder) {
                    LOGE("Couldn't find encoder for video");
                    return;
                }
                /* put sample parameters */
                enc_video_codec_ctx->bit_rate = 400000;
                /* resolution must be a multiple of two */
                enc_video_codec_ctx->width = 352;
                enc_video_codec_ctx->height = 288;
                /* frames per second */
                enc_video_codec_ctx->time_base = (AVRational){1,25};
                /* emit one intra frame every ten frames
                 * check frame pict_type before passing frame
                 * to encoder, if frame->pict_type is AV_PICTURE_TYPE_I
                 * then gop_size is ignored and the output of encoder
                 * will always be I frame irrespective to gop_size
                 */
                enc_video_codec_ctx->gop_size = 10;
                enc_video_codec_ctx->max_b_frames = 1;
                enc_video_codec_ctx->pix_fmt = AV_PIX_FMT_YUV420P;
                if(0 > avcodec_open2(enc_video_codec_ctx, encoder, NULL)) {
                    LOGE("Couldn't open video encoder");
                    return;
                }

                if (output_format_context->oformat->flags & AVFMT_GLOBALHEADER)
                    enc_video_codec_ctx->flags |= CODEC_FLAG_GLOBAL_HEADER;
            }
            break;
            case AVMEDIA_TYPE_AUDIO:
            {

                    AVStream *input_stream = input_format_context->streams[i];
                    AVCodecContext *input_codec_ctx = input_stream->codec;

                    AVStream *out_stream = avformat_new_stream(output_format_context, NULL);
                    if(NULL == out_stream) {
                        LOGE("Couldn't create new output stream");
                        return;
                    }

                AVCodec *encoder = avcodec_find_encoder(AV_CODEC_ID_MP2);
                enc_audio_codec_ctx = avcodec_alloc_context3(encoder);
                out_stream->codec = enc_audio_codec_ctx;
                output_format_context->streams[1] = out_stream;
                if(NULL == encoder) {
                    LOGE("Couldn't find encoder for audio");
                    return;
                }
                LOGI("Audio encoder -> %s", encoder->name);
                enc_audio_codec_ctx->sample_rate=dec_audio_codec_ctx->sample_rate;
                enc_audio_codec_ctx->channel_layout=dec_audio_codec_ctx->channel_layout;
                enc_audio_codec_ctx->channels=av_get_channel_layout_nb_channels(enc_audio_codec_ctx->channel_layout);
                enc_audio_codec_ctx->sample_fmt=encoder->sample_fmts[0];
                enc_audio_codec_ctx->time_base = (AVRational){1, enc_audio_codec_ctx->sample_rate};

                if(0 > avcodec_open2(enc_audio_codec_ctx, encoder, NULL)) {
                    LOGE("Couldn't open audio encoder");
                    return;
                }

                if (output_format_context->oformat->flags & AVFMT_GLOBALHEADER)
                    enc_audio_codec_ctx->flags |= CODEC_FLAG_GLOBAL_HEADER;
            }
            break;
        }
    }

    av_dump_format2(output_format_context);

    if (!(output_format_context->oformat->flags & AVFMT_NOFILE)) {
        int ret = avio_open(&output_format_context->pb, output_path, AVIO_FLAG_WRITE);
        if (ret < 0) {
            LOGE("Could not open output file '%s'", output_path);
            return;
        }
    }

    /* init muxer, write output file header */
    ret = avformat_write_header(output_format_context, NULL);
    if (ret < 0) {
        LOGE("Error occurred when opening output file\n");
        return;
    }

    if(0 > init_filters()) {
        LOGE("Fail init filters");
        return;
    }

    avformat_close_input(&input_format_context);
    avformat_free_context(output_format_context);
}
