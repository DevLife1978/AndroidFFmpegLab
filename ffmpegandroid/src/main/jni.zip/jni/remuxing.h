#include "log.h"

int remuxing(const char * input, const char * output);