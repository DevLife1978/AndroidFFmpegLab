#include <jni.h>
#include <android/log.h>
#include <libavformat/avformat.h>

void av_dump_format_log(AVFormatContext *ic, int index,
                    const char *url, int is_output);